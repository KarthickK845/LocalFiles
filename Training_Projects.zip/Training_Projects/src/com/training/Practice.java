package com.training;

import java.util.List;
import java.util.stream.Collectors;

public class Practice {

	public static void main(String[] args) {
		String str = "Renuka$123*Karthick&456";
//		int cp = str.codePointAt(0);
//		System.out.println(cp);
//		System.out.println((int)'a');
		
		//listing only the letters in the given string
		List<Character> letters = str.chars()
		.filter(Character::isLetter)
		.mapToObj(c->Character.valueOf((char)c))
		.collect(Collectors.toList());
		
		System.out.println(letters);
		
		//listing only the numbers in the given string
		List<String> s= str.chars()
				.filter(Character::isDigit)
				.mapToObj(c->String.valueOf((char)c))
				.collect(Collectors.toList());
		
		System.out.println(s);

		//summing the numbers in the given string
		int sum = str.chars()
		.filter(Character::isDigit)
		.mapToObj(c->Character.getNumericValue(c))
		.reduce(0, (a,b) -> a+b);
		
		System.out.println(sum);
		
		
	}

}
