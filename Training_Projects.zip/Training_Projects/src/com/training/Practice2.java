package com.training;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Practice2 {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(4, 2, 7, 4, 2, 4, 9, 2, 2);

        Map<Integer, Integer> frequencyMap = new HashMap<Integer, Integer>();

        // Count frequencies
        for (Integer num : numbers) {
            if (frequencyMap.containsKey(num)) {
                frequencyMap.put(num, frequencyMap.get(num) + 1);
            } else {
                frequencyMap.put(num, 1);
            }
        }

        // Find max occurrence
        int maxCount = 0;
        int maxElement = 0;
        
        

        for (Map.Entry<Integer, Integer> entry : frequencyMap.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                maxElement = entry.getKey();
            }
        }

        System.out.println("Element with highest duplicates: " + maxElement + " (occurs " + maxCount + " times)");
        
        String input = "programming";

        // Step 1: Count character frequencies
        Map<Character, Long> freqMap = input.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(
                        Function.identity(),
                        Collectors.counting()
                ));

        // Step 2: Filter characters that occur only once
        List<Character> uniqueChars = freqMap.entrySet().stream()
                .filter(entry -> entry.getValue() == 1)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        System.out.println("Characters with single occurrence: " + uniqueChars);
	}

}
