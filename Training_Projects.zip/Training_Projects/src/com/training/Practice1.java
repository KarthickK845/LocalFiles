package com.training;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Practice1 {

	public static void main(String[] args) {
		String str = "Renuka$123*Karthick&456";
		
		//list the strings with letters alone in a given single string
		//your code here
		String[] names  = str.split("[^A-Za-z]+");
		System.out.println(Arrays.toString(names));
		
		String[] numbers = str.split("[^0-9]+");
		System.out.println(Arrays.toString(numbers));
		
		Arrays.stream(str.split("[^0-9]+"))
		.filter(s->!(s.isEmpty()))
		.collect(Collectors.toList()).forEach(System.out::println);
		
		//find the duplicate letters in a given string
		//your code here
		Map<Character, Long> fMap = str.chars()
		.mapToObj(c->(char)c)
		.filter(Character::isLetter)
		.collect(Collectors.groupingBy(c->c, Collectors.counting()));
		
		System.out.println(fMap);
		
		List<Character> characters = fMap.entrySet().stream()
		.filter(f -> f.getValue()>1)
		.map(Map.Entry::getKey)
		.collect(Collectors.toList());
		
		System.out.println(characters);
		
		
		//find the duplicate element with highest occurrence in a given list of integers
		//your code here
		
		
	}

}
