package pack4;

public class B implements A{  //B class is in IS-A relationship with interface A

}
