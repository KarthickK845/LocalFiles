package pack5;

public interface B {
	int x=200;
	void test1();
	void test3();
}
