package pack5;

public class C implements A,B{

	@Override
	public void test3() {
		System.out.println(A.x);
	}

	//implementation of test1() in A or B
	@Override
	public void test1() {
		System.out.println(A.x);
	}

	@Override
	public void test2() {
		System.out.println(B.x);  //ambiguity for x, to resolve we call with interface name
	}

}
