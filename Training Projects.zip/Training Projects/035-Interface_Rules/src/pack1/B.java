package pack1;

public interface B {
	void test3();
	void test4();
}
