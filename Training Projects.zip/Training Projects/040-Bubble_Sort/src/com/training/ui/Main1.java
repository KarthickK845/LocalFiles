package com.training.ui;

import java.util.Arrays;

public class Main1 {

	public static void main(String[] args) {
		//int[] arr = {19,12,6,14,13};
		//int[] arr2 = {200,100,400,300,150};
		
		int[] arr1 = {16,18,17,20,15,19};
				
		for(int i=0;i<arr1.length;i++) {
			System.out.println("i="+i);
			for(int j=0;j<arr1.length-i-1;j++) {
				System.out.println("j="+j);
				if(arr1[j]>arr1[j+1]) {
					int temp;
					temp = arr1[j];
					arr1[j] = arr1[j+1];
					arr1[j+1] = temp;
				}
				System.out.println(Arrays.toString(arr1));
			}
			System.out.println(Arrays.toString(arr1));
		}
		System.out.println(Arrays.toString(arr1));
	}

}
