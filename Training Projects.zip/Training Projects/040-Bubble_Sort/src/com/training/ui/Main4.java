package com.training.ui;

import java.util.Arrays;

import com.training.model.Circle;
import com.training.model.Square;

public class Main4 {

	public static void main(String[] args) {
		// array of Square objects with length 4
		Square[] squares = new Square[4];
		Square s1 = new Square(19);
		Square s2 = new Square(3);

		// populate array with Square objects
		squares[0] = s1;
		squares[1] = s2;
		squares[2] = new Square(25);
		squares[3] = new Square(20);
		
		for(int i=0;i<squares.length;i++) {
			for(int j=0;j<squares.length-i-1;j++) {
				int r = squares[j].compareTo(squares[j+1]);
				
				if(r>0) {
					Square temp;
					temp = squares[j];
					squares[j] = squares[j+1];
					squares[j+1] = temp;
				}
				
			}
			
		}
		
		System.out.println(Arrays.toString(squares));
	}

}
