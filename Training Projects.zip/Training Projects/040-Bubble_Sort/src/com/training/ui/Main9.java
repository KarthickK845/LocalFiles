package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;
import com.training.model.comparators.AccountCustomerNameComparator;

public class Main9 {

	public static void main(String[] args) {
		Account account1 = new Account("Karan", 3000.00);
		Account account2 = new Account("Bala", 14000.00);
		Account account3 = new Account("Sheela", 30000.00);
		Account account4 = new Account("Ruban", 4000.00);
		
		Account[] accounts = {account1, account2, account3, account4};
		
		for(int i=0;i<accounts.length;i++) {
			for(int j=0;j<accounts.length-i-1;j++) {
				//Sorting based on account customer Name
				AccountCustomerNameComparator comparator = new AccountCustomerNameComparator();
				int r = comparator.compare(accounts[j], accounts[j+1]);
				
				if(r>0) {
					Account temp;
					temp = accounts[j];
					accounts[j] = accounts[j+1];
					accounts[j+1] = temp;
				}
				
			}
			
		}
		
		System.out.println(Arrays.toString(accounts));

	}

}
