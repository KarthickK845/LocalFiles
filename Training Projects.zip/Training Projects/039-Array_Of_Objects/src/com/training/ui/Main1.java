package com.training.ui;

import com.training.model.Circle;

public class Main1 {

	public static void main(String[] args) {
		//Array of References
		
		int a = 100;
		int b = 200;
		int c = 300;
		
		//int[] arr = {a,b,c};  //1 way of creating array of int
		int[] arr = new int[3];   //array of primitive values
		arr[0]=a;
		arr[1]=b;
		arr[2]=c;

		Circle[] circles = new Circle[4];  //array of objects
		Circle c1 = new Circle(10);
		Circle c2 = new Circle(5);
		Circle c3 = new Circle(15);
		
		circles[0] = c1;
		circles[1] = c2;
		circles[2] = c3;
		circles[3] = new Circle(30);
		
		for(Circle circle : circles)
		{
			//System.out.println(circle.getRadius()+","+circle.getArea());
			System.out.println(circle);
		}
		
		circles = null;
		c1 = null;
		c2 = null;
		c3 = null;
		//(OR)
		//c1=c2=c3=null;
	}

}
