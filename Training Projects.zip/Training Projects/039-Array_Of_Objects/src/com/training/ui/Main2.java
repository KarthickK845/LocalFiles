package com.training.ui;

import com.training.model.Square;

public class Main2 {

	public static void main(String[] args) {
		//array of Square objects with length 4
		Square[] squares = new Square[4];
		Square s1 = new Square(3);
		Square s2 = new Square(9);
		
		//populate array with Square objects
		squares[0]=s1;
		squares[1]=s2;
		squares[2]=new Square(15);
		squares[3]=new Square(20);
		
		//iterate the array and print size and area
		for(Square s:squares) {
			System.out.println(s.getSize()+","+s.getArea());
			//System.out.println(s);
		}
		
		squares=null;
		s1=s2=null;
	}

}
