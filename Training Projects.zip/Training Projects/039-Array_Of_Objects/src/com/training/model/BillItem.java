package com.training.model;

public class BillItem implements Comparable{
	private String itemName;
	private int quantity;
	private double price;
	
	public BillItem(String itemName, int quantity, double price) {
		super();
		this.itemName = itemName;
		this.quantity = quantity;
		this.price = price;
	}

	@Override
	public int compareTo(Object o) {
		BillItem other = (BillItem) o;
		//return this.price-other.price; //error as we cannot return double value
		
		//to compare double value, write like below
//		if(this.price<other.price)
//			return -1;
//		if(this.price>other.price)
//			return 1;
//		return 0;
		
		//compare Strings
		int r = this.itemName.compareTo(other.itemName);
		return r;
		
	}
	
	public String getItemName() {
		return itemName;
	}



	public void setItemName(String itemName) {
		this.itemName = itemName;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}
	
	public double getItemValue(){
		return this.quantity*this.price;
	}

	

	@Override
	public String toString() {
		return "BillItem [itemName=" + itemName + ", quantity=" + quantity + ", price=" + price + ", getItemValue()="
				+ getItemValue() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof BillItem))
			return false;
		BillItem other = (BillItem) obj;
		if (itemName == null) {
			if (other.itemName != null)
				return false;
		} else if (!itemName.equals(other.itemName))
			return false;
		return true;
	}
	
	
}
