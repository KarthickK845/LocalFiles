package com.training.model;

public class Manager extends Employee {

	private int employeeCount;

	public Manager(int id, String name, String gender, String cityName, double basic, int employeeCount) {
		super(id, name, gender, cityName, basic);
		this.employeeCount = employeeCount;
	}

	public Manager() {
		super();
	}

	public int getEmployeeCount() {
		return employeeCount;
	}

	public void setEmployeeCount(int employeeCount) {
		this.employeeCount = employeeCount;
	}
	
	@Override
	public double getNetSalary() {
		double net = super.getNetSalary();
		net=net+(employeeCount*1000);
		return net;
	}

	@Override
	public String toString() {
		return "Manager [employeeCount=" + employeeCount + ", getNetSalary()=" + getNetSalary() + ", getId()=" + getId()
				+ ", getName()=" + getName() + ", getGender()=" + getGender() + ", getCityName()=" + getCityName()
				+ ", getBasic()=" + getBasic() + "]";
	}
	
	//no need to override equals,hashCode here as we are already overriding based on ID in Employee parent class
	
}
