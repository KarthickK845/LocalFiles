
public class Main3 {

	public static void main(String[] args) {
		byte a =90;
		short b = 888;
		
		int c = 200;
		long d = 900;
		
		System.out.println((a==b) & (c==d));
		System.out.println((a==90) & (c==d));
		
		//short circuit AND operator
		
		System.out.println((a==90) && (++c==d));	//evaluates both conditions
		System.out.println(c);
		
		//logical OR operator
		
		System.out.println((b==888) | (++d==500));
		System.out.println(d);
		
		//short circuit OR operator
		d=900;
		
				System.out.println((b==888) || (++d==500));
				System.out.println(d);
	}

}
