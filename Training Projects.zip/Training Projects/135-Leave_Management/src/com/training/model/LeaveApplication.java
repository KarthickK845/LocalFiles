package com.training.model;

import java.time.LocalDate;

public class LeaveApplication {
	int employeeId;
	int managerId;
	LocalDate fromDate;
	LocalDate toDate;
	String reason;
	String approvedOrRejected;
	public LeaveApplication(int employeeId, int managerId, LocalDate fromDate, LocalDate toDate, String reason,
			String approvedOrRejected) {
		super();
		this.employeeId = employeeId;
		this.managerId = managerId;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.reason = reason;
		this.approvedOrRejected = null;
	}
	public LeaveApplication() {
		super();
		this.approvedOrRejected = null;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public LocalDate getFromDate() {
		return fromDate;
	}
	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}
	public LocalDate getToDate() {
		return toDate;
	}
	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getApprovedOrRejected() {
		return approvedOrRejected;
	}
	public void setApprovedOrRejected(String approvedOrRejected) {
		this.approvedOrRejected = approvedOrRejected;
	}
	@Override
	public String toString() {
		return "LeaveApplication [employeeId=" + employeeId + ", managerId=" + managerId + ", fromDate=" + fromDate
				+ ", toDate=" + toDate + ", reason=" + reason + ", approvedOrRejected=" + approvedOrRejected + "]";
	}
	
	
	
}
