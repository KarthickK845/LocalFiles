package com.training.ui;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.training.model.Employee;
import com.training.model.LeaveApplication;
import com.training.model.Manager;

public class Main {
	static List<Employee> employees = new LinkedList<>();

	static List<Manager> managers = new LinkedList<>();

	static List<LeaveApplication> allLeaveRequests = new LinkedList<>();

	static Scanner scanner = new Scanner(System.in);

	public static void init() {
		Employee emp1 = new Employee(101, "Abhishek");
		Employee emp2 = new Employee(102, "Elango");
		Employee emp3 = new Employee(103, "Mridula");
		Employee emp4 = new Employee(104, "Usha");
		Employee emp5 = new Employee(105, "Hari");
		Employee emp6 = new Employee(106, "Thakur");

		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
		employees.add(emp5);
		employees.add(emp6);

		Manager mgr1 = new Manager(91, "Ram", "IT-Infra");
		Manager mgr2 = new Manager(92, "Jane", "Retail");

		managers.add(mgr1);
		managers.add(mgr2);
	}

	public static void main(String[] args) {
		String role;
		String loginName;
		int exit = 0;
		init();

		do {
			System.out.println("Are you Manager or Employee ?");
			
			role = scanner.next();
			
			System.out.println("Enter your name : ");
			loginName = scanner.next();	

			if (role.equalsIgnoreCase("Employee")) {
				applyLeave(loginName);
			} else if (role.equalsIgnoreCase("Manager")) {
				getAllLeaveRequests(loginName);
			} 
			
//			System.out.println("Enter 1 to exit or 0 to continue : ");
//			exit = scanner.nextInt();

		}while (true);

		// if role is employee, take input for leave application
		// if role is manager, we should display all the leave applications submitted to
		// this Manager
		// Manager will see the list and he will either approve or reject the leave
		// when an employee is already having history of leave, that should be displayed
		// before new leave application
		// if already have leave history, leave application must be rejected

	}

	public static void applyLeave(String loginName) {
		System.out.println("======= APPLY LEAVE ========");

		Employee emp = null;
		for (Employee employee : employees) {
			if (employee.getName().equalsIgnoreCase(loginName)) {
				emp = employee;
			}
		}

		if (emp != null) {

			System.out.println("Enter your Manager ID : ");
			int mgrId = scanner.nextInt();

			System.out.println("Enter your FROM Date of Leave : ");

			LocalDate fromDate = LocalDate.parse(scanner.next());

			System.out.println("Enter your TO Date of Leave : ");
			LocalDate toDate = LocalDate.parse(scanner.next());

			System.out.println("Enter your Leave Reason : ");
			String reason = scanner.next();

			LeaveApplication leaveApp = new LeaveApplication();
			leaveApp.setEmployeeId(emp.getId());
			leaveApp.setManagerId(mgrId);
			leaveApp.setFromDate(fromDate);
			leaveApp.setToDate(toDate);
			leaveApp.setReason(reason);

			System.out.println("Leave Applied Successfully");

			allLeaveRequests.add(leaveApp);
		} else {
			System.out.println("Employee Not Present !");
		}
	}

	public static List<LeaveApplication> getAllLeaveRequests(String loginName) {
		System.out.println("Enter Manager ID : ");
		int mgrId = scanner.nextInt();
				
		System.out.println("======= ALL LEAVE REQUESTS ========");
		
		List<LeaveApplication> leaveRequestsToManager = allLeaveRequests.stream()
				.filter(la -> mgrId == la.getManagerId()).collect(Collectors.toList());
		
		System.out.println(leaveRequestsToManager);
		
		return leaveRequestsToManager;
		

	}
	
	public static void approveOrRejectLeave(List<LeaveApplication> leaveRequestsToManager) {
			List<Integer> employeeIds = allLeaveRequests.stream()
					.map(la -> la.getEmployeeId()).collect(Collectors.toList());
			
			for(LeaveApplication leaveApp : leaveRequestsToManager) {
				
				if(leaveApp.getApprovedOrRejected()==null)
					leaveApp.setApprovedOrRejected("approved");
				else
					leaveApp.setApprovedOrRejected("rejected");
					
			}
			
			System.out.println(leaveRequestsToManager);
			
			
	}
}
