package com.training.ui;

import java.util.Arrays;

import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;

public class Main10 {

	public static void main(String[] args) {
		// Array of Employees - Selection sort natural order
		Manager manager = new Manager(101, "Ram", "MALE", "Mumbai", 1000.00, 12);
		SalesEmployee salesEmployee1 = new SalesEmployee(102, "Dinesh", "MALE", "Delhi", 1000.00, 100000.00);
		SalesEmployee salesEmployee2 = new SalesEmployee(103, "Kiran", "MALE", "Pune", 1000.00, 200000.00);
		Employee employee = new Employee(104, "Menaka", "FEMALE", "Cochin", 1000.00);

		Employee[] employees = { manager, salesEmployee1, salesEmployee2, employee };

		int n = employees.length;

		// Selection sort Natural order - Based on Employee ID
		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i;
			for (int j = i + 1; j < n; j++) {
				int r = employees[j].compareTo(employees[imin]);
				if (r < 0)
					imin = j;
			}
			Employee temp;
			temp = employees[i];
			employees[i] = employees[imin];
			employees[imin] = temp;
		}
		System.out.println("Selection sort - Employee ID - employees");
		System.out.println(Arrays.toString(employees));
	}

}
