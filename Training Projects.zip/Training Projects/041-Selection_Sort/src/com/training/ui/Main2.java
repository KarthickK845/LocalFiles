package com.training.ui;

import java.util.Arrays;

public class Main2 {

	public static void main(String[] args) {
		//Selection Sort of double array
		double[] prices = { 14.0, 12.0, 10.0, 50.0, 18.0 };
		int n = prices.length;
		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i; // 0
			// System.out.println("imin = "+imin);
			for (int j = i + 1; j < n; j++) {
				// System.out.println("j = "+j);
				if (prices[j] < prices[imin])
					imin = j;	
			}
			double temp;
			temp = prices[i];
			prices[i] = prices[imin];
			prices[imin] = temp;
		}
		System.out.println("array of double values");
		System.out.println(Arrays.toString(prices));
	}
}
