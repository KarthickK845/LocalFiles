package com.training.ui;

import java.util.Arrays;

public class Main1 {

	public static void main(String[] args) {
		// Selection Sort of array of integers
		int[] arr = { 12, 19, 55, 2, 16 };
		int n = arr.length;
		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i; // 0
			System.out.println("imin="+imin);
			for (int j = i + 1; j < n; j++) {
				System.out.println("j="+j);
				if (arr[j] < arr[imin]) {
					imin = j;
				}
				System.out.println("Inside for 2"+Arrays.toString(arr));
			}
			int temp;
			temp = arr[i];
			arr[i] = arr[imin];
			arr[imin] = temp;
			System.out.println(Arrays.toString(arr));
		}
		System.out.println("array of integers");
		System.out.println(Arrays.toString(arr));
	}

}
