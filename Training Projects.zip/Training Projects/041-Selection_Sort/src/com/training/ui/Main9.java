package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;
import com.training.model.comparators.AccountCustomerNameComparator;

public class Main9 {

	public static void main(String[] args) {
		// Array of Account objects
		Account account1 = new Account("Kala", 3000.00);
		Account account2 = new Account("Bala", 4000.00);
		Account account3 = new Account("Sheela", 14000.00);
		Account account4 = new Account("Reena", 12000.00);

		Account[] accounts = { account1, account2, account3, account4 };

		int n = accounts.length;

		// Selection sort based on Account Customer Name
		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i;
			for (int j = i + 1; j < n; j++) {
				AccountCustomerNameComparator comparator = new AccountCustomerNameComparator();
				int r = comparator.compare(accounts[j], accounts[imin]);
				if (r < 0)
					imin = j;
			}
			Account temp;
			temp = accounts[i];
			accounts[i] = accounts[imin];
			accounts[imin] = temp;
		}
		System.out.println("Selection sort - Customer Name - Accounts");
		System.out.println(Arrays.toString(accounts));

	}

}
