package com.training.ui;

import java.util.Arrays;

import com.training.model.Person;

public class Main13 {

	public static void main(String[] args) {
		// Array of Persons - Selection sort natural order
		Person person1 = new Person("Ram", 50);
		Person person2 = new Person("Sham", 14);

		Person[] persons = { person1, person2, new Person("Karthi", 30), new Person("Hari", 18) };

		int n = persons.length;
		
		// Selection sort - Based on Person Age
		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i; // 0
			for (int j = i + 1; j < n; j++) {
				int r = persons[j].compareTo(persons[imin]);
				if (r < 0)
					imin = j;
			}
			Person temp;
			temp = persons[i];
			persons[i] = persons[imin];
			persons[imin] = temp;
		}
		System.out.println("Selection sort - Person age - persons");
		System.out.println(Arrays.toString(persons));
	}

}
