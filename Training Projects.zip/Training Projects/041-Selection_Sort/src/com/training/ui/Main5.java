package com.training.ui;

import java.util.Arrays;

import com.training.model.BillItem;

public class Main5 {

	public static void main(String[] args) {
		// Array of BillItems - Selection sort - Based on itemName
		BillItem b1 = new BillItem("Redmi", 3, 14000.00);

		BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), new BillItem("OPPO", 4, 20000.00),
				new BillItem("IPhone", 4, 24000.00), b1 };

		int n = billItems.length;

		// Selection sort - Based on itemName
		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i; // 0
			for (int j = i + 1; j < n; j++) {
				int r = billItems[j].compareTo(billItems[imin]);
				if (r < 0)
					imin = j;
			}
			BillItem temp;
			temp = billItems[i];
			billItems[i] = billItems[imin];
			billItems[imin] = temp;
		}
		System.out.println("Selection sort - itemName - Billitems");
		System.out.println(Arrays.toString(billItems));
	}
}
