package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;
import com.training.model.BillItem;

public class Main8 {

	public static void main(String[] args) {
		// Array of Account objects - Selection sort - based on balance
		Account account1 = new Account("Kala", 3000.00);
		Account account2 = new Account("Bala", 4000.00);
		Account account3 = new Account("Sheela", 14000.00);
		Account account4 = new Account("Reena", 12000.00);

		Account[] accounts = { account1, account2, account3, account4 };

		int n = accounts.length;

		// Selection sort - based on balance
		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i; // 0
			for (int j = i + 1; j < n; j++) {
				int r = accounts[j].compareTo(accounts[imin]);
				if (r < 0)
					imin = j;
			}
			Account temp;
			temp = accounts[i];
			accounts[i] = accounts[imin];
			accounts[imin] = temp;
		}
		System.out.println("Selection sort - account balance - Accounts");
		System.out.println(Arrays.toString(accounts));

	}

}
