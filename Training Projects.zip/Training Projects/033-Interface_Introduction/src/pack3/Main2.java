package pack3;

import pack2.Employee;

public class Main2 {

	public static void main(String[] args) {
		
		Employee employee = new Employee();
		employee.setId(101);
		employee.setName("Kiran");
		employee.setBasicSalary(1000.00);
		employee.setGrade('A');
		
		System.out.println(employee.computeAllowance());
		System.out.println(employee.computeTax());
		System.out.println(employee.computeNetSalary());
		
		System.out.println("-------------------------------------------------------");
		
		Employee employee2 = new Employee(102, "Nirmala", 2000.00, 'C');
		System.out.println(employee2.computeAllowance());
		System.out.println(employee2.computeTax());
		System.out.println(employee2.computeNetSalary());
		
		System.out.println("-------------------------------------------------------");
		
		
	}

}
