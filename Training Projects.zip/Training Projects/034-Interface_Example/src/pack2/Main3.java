package pack2;

import pack1.Shape;
import pack1.Square;

public class Main3 {

	public static void main(String[] args) {
		Shape shape;
		shape = new Square();  //just change the object Circle to Square and that resp. class methods will be called
		
		//below code will be same for both Circle and Square, no need of changes
		shape.setSize(10);
		System.out.println(shape.getSize());
		System.out.println(shape.getArea());
	}

}
