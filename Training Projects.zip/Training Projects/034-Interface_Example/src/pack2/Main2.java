package pack2;

import pack1.Circle;
import pack1.Square;

public class Main2 {

	public static void main(String[] args) {
		/*Square square = new Square();
		square.setSize(10);
		System.out.println(square.getSize());
		System.out.println(square.computeArea());*/
		
		//cannot use same Square object for Circle methods, so we have to re-write as per Circle object

		Circle c = new Circle();
		c.setRadius(10);
		System.out.println(c.getRadius());
		System.out.println(c.calculateArea());
	}

}
