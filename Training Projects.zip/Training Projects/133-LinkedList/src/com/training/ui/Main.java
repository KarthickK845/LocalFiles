package com.training.ui;

import java.util.List;

import com.training.linkedlist.LinkedList;
import com.training.model.Customer;

public class Main {

	public static void main(String[] args) {
		LinkedList<Customer> customers = new LinkedList<Customer>();
		
		Customer customer1 = new Customer(1,"Ragul");
		Customer customer2 = new Customer(2,"Ramesh");
		Customer customer3 = new Customer(3,"Lakshmi");
		
		customers.addToList(customer1);
		customers.addToList(customer2);
		customers.addToList(customer3);
		
		customers.print();
		
		System.out.println("Count : "+customers.count());
		
		System.out.println("<<--- Inserting after Customer 1 --->>");
		customers.insertAfter(customer1, new Customer(4,"Ryan"));
		
		customers.print();
		
		System.out.println("Count : "+customers.count());
	}

}
