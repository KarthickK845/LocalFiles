package com.training.linkedlist;

public class Node<T>  {
	public T data;
	public Node<T> nextNode;
	
	public Node(T data) {
		super();
		this.data = data;
		this.nextNode = null;
	}
	
	
}
