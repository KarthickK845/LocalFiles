package com.training.linkedlist;

public class LinkedList<T> {
	public static Node start = null;
	
	public void addToList(T data) {
		//implement adding
		Node new_node = new Node(data);
		new_node.nextNode = null;
		
		if(start==null) {
			start = new_node;
		}
		else {
			Node<T> current = start;
			while(current.nextNode!=null) {
				current=current.nextNode;
			}
			current.nextNode = new_node;
		}
	}
	
	public int count() {
		//return how many elements are in LinkedList
		Node<T> current = start;
		int count = 0;
		while(current!=null) {
			count++;
			current= current.nextNode;
		}
		return count;
	}
	
	public void print() {
		Node<T> current = start;
		while(current!=null) {
			System.out.println(current.data);
			current = current.nextNode;
		}
	}
	
	public void insertAfter(T after, T data) {
		Node<T> current = start;
		Node<T> previous = null;
		
		while(current!=null) {
			previous=current;
			if(current.data==after)
				break;
			
			current=current.nextNode;
		}
			Node<T> new_node = new Node<T>(data);
			new_node.nextNode = current.nextNode;
			previous.nextNode=new_node;
		
	}
}
