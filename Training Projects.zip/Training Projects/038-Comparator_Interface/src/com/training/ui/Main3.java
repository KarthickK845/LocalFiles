package com.training.ui;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main3 {

	public static void main(String[] args) {
		Person person1 = new Person("Ram", 50);
		Person person2 = new Person("Ram", 40);
		
		PersonNameComparator comparator = new PersonNameComparator();
		int r = comparator.compare(person1, person2);
		System.out.println(r);
		
		if(r<0)
			System.out.println(person1.getName()+" is less than "+person2.getName());
		if(r==0)
			System.out.println(person1.getName()+" is equal to "+person2.getName());
		if(r>0)
			System.out.println(person1.getName()+" is greater than "+person2.getName());
	}

}
