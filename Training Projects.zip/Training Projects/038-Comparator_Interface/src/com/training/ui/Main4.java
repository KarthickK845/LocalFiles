package com.training.ui;

import com.training.model.Account;
import com.training.model.comparators.AccountCustomerNameComparator;

public class Main4 {

	public static void main(String[] args) {
		Account account1 = new Account("Kala", 3000.00);
		Account account2 = new Account("Bala", 4000.00);
		
		AccountCustomerNameComparator comparator = new AccountCustomerNameComparator();
		
		int r = comparator.compare(account1, account2);
		System.out.println(r);
		
		if(r<0)
			System.out.println(account1.getCustomerName()+" is less than "+account2.getCustomerName());
		if(r==0)
			System.out.println(account1.getCustomerName()+" is equal to "+account2.getCustomerName());
		if(r>0)
			System.out.println(account1.getCustomerName()+" is greater than "+account2.getCustomerName());
	}

}
