package com.training.ui;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main2 {

	public static void main(String[] args) {
		BillItem billItem1 = new BillItem("DELL", 12, 50000.00);
		BillItem billItem2 = new BillItem("IPhone", 10, 50000.00);
		
		BillItemPriceComparator comparator = new BillItemPriceComparator();
		
		int r = comparator.compare(billItem1, billItem2);
		System.out.println(r);
		
		if(r<0)
			System.out.println("BillItem1 price is less than BillItem2 price");
		if(r==0)
			System.out.println("BillItem1 price is equal to BillItem2 price");
		if(r>0)
			System.out.println("BillItem1 price is greater than BillItem2 price");

	}

}
