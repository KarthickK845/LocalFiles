package com.training.ui;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemQuantityComparator;

public class Main1 {

	public static void main(String[] args) {
		BillItem billItem1 = new BillItem("DELL", 12, 49000.00);
		BillItem billItem2 = new BillItem("IPhone", 10, 50000.00);
		
		BillItemQuantityComparator comparator = new BillItemQuantityComparator();
		
		int r = comparator.compare(billItem1, billItem2);
		System.out.println(r);
		
		if(r<0)
			System.out.println("BillItem1 quantity is less than BillItem2 quantity");
		if(r==0)
			System.out.println("BillItem1 quantity is equal to BillItem2 quantity");
		if(r>0)
			System.out.println("BillItem1 quantity is greater than BillItem2quantity");
	}

}
