package com.training.model;

public class Account implements Comparable{
	String customerName;
	double balance;
	
	public Account(String customerName, double balance) {
		super();
		this.customerName = customerName;
		this.balance = balance;
	}

	@Override
	public int compareTo(Object o) {
		Account ac = (Account) o;
		
		//comparing balance
		if(this.balance<ac.balance)
			return -1;
		if(this.balance>ac.balance)
			return 1;
		return 0;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
