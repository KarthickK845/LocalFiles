package com.training.ui;

import java.util.PriorityQueue;

public class Main3 {

	public static void main(String[] args) {
		PriorityQueue<String> names;
		names = new PriorityQueue<>();
		
		names.add("John");
		names.add("Abinaya");
		names.add("Mythili");
		names.add("Karan");
		
		//returns in natural sorting order and removes it from queue
		System.out.println(names.poll());
		System.out.println(names.poll());
		System.out.println(names.poll());
		System.out.println(names.poll());
	}

}
