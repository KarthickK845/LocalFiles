package com.training.ui;

import java.util.LinkedList;
import java.util.Queue;

public class Main1 {

	public static void main(String[] args) {
		//Any List Implementation like ArrayList,LinkedList implements Queue interface
		//Queue FIFO Data Structure
		Queue<Integer> queue = new LinkedList<>();
		
		queue.add(20);
		queue.add(16);
		queue.add(21);
		queue.add(12);
		queue.add(17);
		
		System.out.println(queue);
		
		Integer temp = queue.peek();  //returns First element in Queue but doesn't remove from Queue
		System.out.println(temp);
		
		System.out.println(queue);
		
		Integer result = queue.poll();  //returns First element in Queue and removes it
		System.out.println(result);
		
		System.out.println(queue);
		
		result = queue.poll();
		System.out.println(result);
		
		result = queue.poll();
		System.out.println(result);
		
		
		
		System.out.println(queue);
	}

}
