package com.training.ui;

import java.util.Comparator;
import java.util.PriorityQueue;

import com.training.model.Person;

public class Main4 {

	public static void main(String[] args) {
		PriorityQueue<Person> persons;
		persons = new PriorityQueue<>(Comparator.reverseOrder());
		//above is static method in Comparator interface
		persons.add(new Person(30,170,65));
		persons.add(new Person(26,174,60));
		persons.add(new Person(25,178,55));
		persons.add(new Person(27,162,57));
		persons.add(new Person(29,164,78));
		
		System.out.println(persons.poll());
		System.out.println(persons.poll());
		System.out.println(persons.poll());
		System.out.println(persons.poll());
		System.out.println(persons.poll());
	}

}
