
public class Main {

	public static void main(String[] args) {
		byte v1 = -128;			//numeric 
		System.out.println(Byte.MIN_VALUE);
		System.out.println(Byte.MAX_VALUE);
		
		short v2=15000;
		System.out.println(Short.MIN_VALUE);
		System.out.println(Short.MAX_VALUE);
		
		int v3=200000;
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		
		long v4=40000000;
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MAX_VALUE);
		
		char v5 = 'A';
		//min value \u0000 max value \uFFFF
		//blank only for below
		System.out.println(Character.MIN_VALUE);
		System.out.println(Character.MAX_VALUE);
		
		float v6 = 80.00056f;	//IEEE format (8.0056e10f) numeric data with precision
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);
		
		double v7 = 80.00056f;	//IEEE format (8.0056e10f) numeric data with precision
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);
	}

}
