
public class MainDemo {

	public static void main(String[] args) {
		int N = 3;
		int M = 2;
		int F[] = {1,3,5,5,7};
		int B[] = {2,3,12,10,9};
		System.out.println(F.length+B.length);
		int totalCost = 0,lowestCost = 0;
		for(int i = 0; i<N+M;i++) {
			lowestCost = Integer.min(F[i], B[i]);
			totalCost = totalCost+ lowestCost;
		}
System.out.println(totalCost);
	}

}
