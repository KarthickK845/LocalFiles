import java.util.Scanner;

public class Main1 {

		public static void main(String[] args) {
//			String name;
//			Scanner sc = new Scanner(System.in);
//			System.out.println("Enter your name : ");
//			name=sc.nextLine();
//			System.out.println(name);
//			
//			int age;
//			System.out.println("Enter your age : ");
//			age=sc.nextInt();
//			System.out.println(age);
//			
//			double salary;
//			System.out.println("Enter your salary : ");
//			salary=sc.nextDouble();
//			System.out.println(salary);
			
			
			Integer i = new Integer(50);
			int a = i;
			
			System.out.println(i+" "+a);
			
			Character ch = 'A';
			char ch1 = ch;
			
			System.out.println(ch+" "+ch1);
		}
}
