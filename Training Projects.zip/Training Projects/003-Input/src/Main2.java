import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		String studentName;
		int mark1, mark2;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name : ");
		studentName = sc.nextLine();
		System.out.println("Enter your mark1 : ");
		mark1 = sc.nextInt();
		System.out.println("Enter your mark2 : ");
		mark2 = sc.nextInt();
		
		int total = mark1+mark2;
		double avg = (mark1+mark2)/2;
		System.out.printf("Student name is %s, Total is %d. Average is %3.2f",studentName,total,avg);
		
	}

}
