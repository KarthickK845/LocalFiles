package com.ust.interim.model;

public class Movie {

}
