package com.ust.interim.ui;

import java.util.Scanner;

import com.ust.interim.model.Movie;

public class Main {

	public static void main(String[] args) {
		Movie movies = new Movie();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of queries: ");
		int q = sc.nextInt();
		if(q<1||q>5000)
			throw new IllegalArgumentException("Invalid num. of queries");
		while(q>0) {
			System.out.println("Enter operation name : ");
			String op = sc.next();
			if(op.equals("BOOK")) {
				System.out.println("Enter customer id");
				int x = sc.nextInt();
				System.out.println("Enter movie ID");
				int y = sc.nextInt();
				System.out.println(movies.book(x,y)?"Booked":"Couldn't book");
			}
		}
	}

}
