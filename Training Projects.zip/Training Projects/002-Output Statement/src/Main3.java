
public class Main3 {

	public static void main(String[] args) {
		int age = 20;
		String name="Kiran";
		double salary=5000.000;
		System.out.printf("My name is %s",name);
		System.out.printf("My name is %s, My Age is %d\n , My salary is %10.2f",name,age,salary);
	}

}
