
public class Main2 {

	public static void main(String[] args) {
		int myAge=30;
		String myName="Karthick";
		System.out.println("My Name is "+myName+" My Age is "+myAge);
	}

}
