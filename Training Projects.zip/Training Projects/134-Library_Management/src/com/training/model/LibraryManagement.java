package com.training.model;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

public class LibraryManagement {
	List<Book> allBooks;

	public LibraryManagement() {
		super();
		this.allBooks=new LinkedList<>();
		Book book1 = new Book("HarryPotter", "JK Rowling", 500, false);
		Book book2 = new Book("Marvel", "Hugh Jones", 200, false);
		Book book3 = new Book("Detective James", "Robert Dan", 750, false);
		Book book4 = new Book("Spy Masters", "John", 600, false);
		Book book5 = new Book("Lord of Rings", "William", 120, false);
		Book book6 = new Book("GOT", "Ralph", 720, false);
		Book book7 = new Book("Queen", "Catherine", 550, false);
		Book book8 = new Book("Alchemist", "Charles", 450, false);
		Book book9 = new Book("Secrets", "Rachel", 800, false);
		Book book10 = new Book("Venice", "Joey", 300, false);
		
		//add all books to allBooks
		this.allBooks.add(book1);
		this.allBooks.add(book2);
		this.allBooks.add(book3);
		this.allBooks.add(book4);
		this.allBooks.add(book5);
		this.allBooks.add(book6);
		this.allBooks.add(book7);
		this.allBooks.add(book8);
		this.allBooks.add(book9);
		this.allBooks.add(book10);
		
	}
	
	public void issueBook(String bookName) {
		//find the book which is issued and change the status as true
		this.allBooks.stream()
					.filter(b -> b.getBookName().equalsIgnoreCase(bookName))
					.forEach(book -> { book.setIssueStatus(true);
					System.out.println("\""+ book.getBookName() +"\" Book is issued successfully");	
					});
					
	}
	
	public void printAvailableBooks() {
		//print the books that are having status as false
		System.out.println("LIST OF AVAILABLE BOOKS : ");
		this.allBooks.stream()
			.filter(book -> !(book.isIssueStatus()))
			.forEach(System.out::println);		
	}
	
	public int getAvailableBooksCount() {
		//returns count of available books status - false
		
		return (int) this.allBooks.stream()
				.filter(book ->!(book.isIssueStatus()))
			.count();
	}
	
	public int getIssuedBookCount() {
		//returns count of issued books status - true
		
		return (int) this.allBooks.stream()
				.filter(book ->book.isIssueStatus())
				.count();
	}
	
}
