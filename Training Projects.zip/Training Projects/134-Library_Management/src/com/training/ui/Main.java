package com.training.ui;

import com.training.model.LibraryManagement;

public class Main {

	public static void main(String[] args) {
		LibraryManagement library = new LibraryManagement();
		
		library.issueBook("Secrets");
		library.issueBook("GOT");
		library.issueBook("Marvel");
		
		library.printAvailableBooks();
		
		System.out.println("NO. OF AVAILABLE BOOKS : "+library.getAvailableBooksCount());
	
		System.out.println("NO. OF ISSUED BOOKS : "+library.getIssuedBookCount());
	}

}
