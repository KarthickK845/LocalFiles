package com.training.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
 
public class Main3 {
 
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
 
		int fendCount;
		int bendCount;
		int totalCost=0;
		int fCount=0,bCount=0;
		fendCount = Integer.parseInt(br.readLine());
		bendCount = Integer.parseInt(br.readLine());
 
		int[] fendCostArray = new int[fendCount + bendCount];
		String[] arr1 = br.readLine().trim().split(" ");
 
		for (int i = 0; i < arr1.length; i++) {
			fendCostArray[i] = Integer.parseInt(arr1[i]);
		}
 
		int[] bendCostArray = new int[fendCount + bendCount];
		String[] arr2 = br.readLine().trim().split(" ");
 
		for (int i = 0; i < arr2.length; i++) {
			bendCostArray[i] = Integer.parseInt(arr2[i]);
		}
 
		System.out.println(Arrays.toString(fendCostArray));
		System.out.println(Arrays.toString(bendCostArray));
 
		List<Integer> list1 = new LinkedList<>();
		for (int i = 0; i < arr1.length; i++) {
			list1.add(Integer.parseInt(arr1[i]));
		}
		System.out.println(list1);
 
		List<Integer> list2 = new LinkedList<>();
		for (int i = 0; i < arr2.length; i++) {
			list2.add(Integer.parseInt(arr2[i]));
		}
		System.out.println(list2);
		
		for(int i=0;i<arr1.length;i++) {
			if(Integer.parseInt(arr1[i])<=Integer.parseInt(arr2[i])) {
				totalCost=totalCost+Integer.parseInt(arr1[i]);
				fCount++;
				if(fCount>fendCount) {
					System.out.println("from front end");
					int min=minimumValueArray(bendCostArray,fendCostArray,bendCount,fendCount);
					totalCost=totalCost+min;
					delete(fendCostArray, bendCostArray);
					bCount++;
					fCount--;
				}
			}
			else
			{
				totalCost=totalCost+Integer.parseInt(arr2[i]);
				bCount++;
				if(bCount>bendCount) {
					System.out.println("from backend");
					int min=minimumValueArray(fendCostArray,bendCostArray,fendCount,bendCount);
					totalCost=totalCost+min;
					delete(fendCostArray, bendCostArray);
					fCount++;
					bCount--;
				}
				
			}
		}
		System.out.println(totalCost);
		System.out.println(fCount);
		System.out.println(bCount);
 
	}
	public static int minimumValueArray(int[] fArray, int[] bArray,int m, int n) {
		int minVlue=Integer.MAX_VALUE;
		for(int i=0;i<m+n;i++)
		{
			int diff=Math.abs(fArray[i]-bArray[i]);
			if(diff<minVlue && diff!=0) {
				minVlue=diff;
			}
		}
		System.out.println(minVlue);
		return minVlue;
	}
	
	public static void delete(int[] fArray, int[] bArray) {
		int minVlue=Integer.MAX_VALUE;
		int pos=0;
		for(int i=0;i<fArray.length;i++) {
			int  diff=Math.abs(fArray[i]-bArray[i]);
			if(diff<minVlue && diff!=0) {
				minVlue=diff;
				pos=i;
			}		  
		}
	  for(int j=pos;j<fArray.length-1;j++) {
		  fArray[j]=fArray[j+1];
		  bArray[j]=bArray[j+1];
	  }
	  
	  }
	
}
 
 
 
 
