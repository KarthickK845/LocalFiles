package com.training.ui;

public class Main4Practice {
	static {
		main(new String[0]);
	}

	public static void main(String[] args) {
		System.out.println("Class-X");
	}

}
