package com.training.ui;

enum Currency{
	US(1.54), EUR(1.0);
	
	Currency(Double amount) {
		this*amount;
	}
}

public class Main6Practice {

	public static void main(String[] args) {
		

	}

}
