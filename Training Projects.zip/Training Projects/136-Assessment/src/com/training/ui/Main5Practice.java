package com.training.ui;

class A extends Thread{

	@Override
	public void run() {
		long threadID = Thread.currentThread().getId();
		System.out.println(threadID + " is running");
	}
	
	
}

public class Main5Practice {

	public static void main(String[] args) {
		A obj = new A();
		
		for(int i = 0;i<5;i++) {
			obj.start();
		}

	}

}
