package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;

public class Main8 {

	public static void main(String[] args) {
		Account account1 = new Account("Kala", 3000.00);
		Account account2 = new Account("Bala", 4000.00);
		Account account3 = new Account("Sheela", 14000.00);
		Account account4 = new Account("Reena", 12000.00);

		Account[] accounts = { account1, account2, account3, account4 };

		int n = accounts.length;
		
		for (int i = 1; i < n; ++i) {
			Account key = accounts[i];
			int j = i - 1;
			
			int r = accounts[j].compareTo(key);
			
			while (j >= 0 && r > 0) {
				accounts[j + 1] = accounts[j];
				j = j - 1;
				if(j>=0)
					r = accounts[j].compareTo(key);
			}
			accounts[j + 1] = key;
		}
		System.out.println("Insertion sort - account balance - Accounts");
		System.out.println(Arrays.toString(accounts));

	}

}
