package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;
import com.training.model.comparators.AccountCustomerNameComparator;

public class Main9 {

	public static void main(String[] args) {
		Account account1 = new Account("Kala", 3000.00);
		Account account2 = new Account("Bala", 4000.00);
		Account account3 = new Account("Sheela", 14000.00);
		Account account4 = new Account("Reena", 12000.00);

		Account[] accounts = { account1, account2, account3, account4 };

		int n = accounts.length;

		AccountCustomerNameComparator comparator = new AccountCustomerNameComparator();

		for (int i = 1; i < n; ++i) {
			Account key = accounts[i];
			int j = i - 1;

			int r = comparator.compare(accounts[j], key);

			while (j >= 0 && r > 0) {
				accounts[j + 1] = accounts[j];
				j = j - 1;
				if (j >= 0)
					r = comparator.compare(accounts[j], key);
			}
			accounts[j + 1] = key;
		}
		System.out.println(Arrays.toString(accounts));

	}

}
