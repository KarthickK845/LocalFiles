package com.training.ui;

import java.util.Arrays;

import com.training.model.Square;

public class Main4 {

	public static void main(String[] args) {
		// Insertion sort Array of square objects
		Square[] squares = new Square[4];
		Square s1 = new Square(9);
		Square s2 = new Square(3);

		// populate array with Square objects
		squares[0] = s1;
		squares[1] = s2;
		squares[2] = new Square(25);
		squares[3] = new Square(20);

		int n = squares.length;

		for (int i = 1; i < n; ++i) {
			Square key = squares[i];
			int j = i - 1;
			int r = squares[j].compareTo(key);
			while (j >= 0 && r > 0) {
				squares[j + 1] = squares[j];
				j = j - 1;
				if(j>=0)
					r = squares[j].compareTo(key);
			}
			squares[j + 1] = key;
		}
		System.out.println(Arrays.toString(squares));
	}

}
