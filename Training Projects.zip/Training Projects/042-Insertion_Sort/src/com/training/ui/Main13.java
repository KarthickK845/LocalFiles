package com.training.ui;

import java.util.Arrays;

import com.training.model.Person;

public class Main13 {

	public static void main(String[] args) {
		Person person1 = new Person("Ram", 50);
		Person person2 = new Person("Sham", 14);

		Person[] persons = { person1, person2, new Person("Karthi", 30), new Person("Hari", 18) };

		int n = persons.length;
		
		for (int i = 1; i < n; ++i) {
			Person key = persons[i];
			int j = i - 1;
			
			int r = persons[j].compareTo(key);
			
			while (j >= 0 && r > 0) {
				persons[j + 1] = persons[j];
				j = j - 1;
				if(j>=0)
					r = persons[j].compareTo(key);
			}
			persons[j + 1] = key;
		}
		System.out.println("Insertion sort - age - Persons");
		System.out.println(Arrays.toString(persons));

	}

}
