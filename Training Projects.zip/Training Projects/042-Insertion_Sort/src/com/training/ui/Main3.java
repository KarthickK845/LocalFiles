package com.training.ui;

import java.util.Arrays;

import com.training.model.Circle;

public class Main3 {

	public static void main(String[] args) {
		// Insertion Sort - Circle array
		Circle[] circles = new Circle[5];  //array of objects
		Circle c1 = new Circle(10);
		Circle c2 = new Circle(25);
		Circle c3 = new Circle(15);
		
		circles[0] = c1;
		circles[1] = c2;
		circles[2] = c3;
		circles[3] = new Circle(30);
		circles[4] = new Circle(5);
		
		int n = circles.length;
		
		for (int i = 1; i < n; ++i) {
			Circle key = circles[i];
			int j = i - 1;
			System.out.println("i="+i+" j="+j+" key="+key);
			int r = circles[j].compareTo(key);
			System.out.println("r="+r);
			//while (j >= 0 && circles[j].compareTo(key) > 0) {
			while (j >= 0 && r > 0) {
				circles[j + 1] = circles[j];
				j = j - 1;
				if(j>=0)
					r = circles[j].compareTo(key);
			}
			circles[j + 1] = key;
		}
		System.out.println(Arrays.toString(circles));
	}

}
