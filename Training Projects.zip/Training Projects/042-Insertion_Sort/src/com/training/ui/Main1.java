package com.training.ui;

import java.util.Arrays;

public class Main1 {

	public static void main(String[] args) {
		//Insertion Sort - int array
		int arr[] = { 12, 19, 55, 2, 16, 60 };
		int n = arr.length;

		for (int i = 1; i < n; ++i) {
			int key = arr[i];
			int j = i - 1;
			System.out.println("i="+i+" j="+j+" key="+key);
			while (j >= 0 && arr[j] > key) {
				arr[j + 1] = arr[j];
				j = j - 1;
				System.out.println("j="+j);
				System.out.println(Arrays.toString(arr));
			}
			arr[j + 1] = key;
			System.out.println(Arrays.toString(arr));
		}
		System.out.println(Arrays.toString(arr));
	}
}
