package com.training.ui;

import java.util.Arrays;

import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;
import com.training.model.comparators.EmployeeBasicSalaryAscendingComparator;

public class Main11 {

	public static void main(String[] args) {
		Manager manager = new Manager(101, "Ram", "MALE", "Mumbai", 18000.00, 12);
		SalesEmployee salesEmployee1 = new SalesEmployee(102, "Dinesh", "MALE", "Delhi", 11000.00, 100000.00);
		SalesEmployee salesEmployee2 = new SalesEmployee(103, "Kiran", "MALE", "Pune", 10000.00, 200000.00);
		Employee employee = new Employee(104, "Menaka", "FEMALE", "Cochin", 17000.00);

		Employee[] employees = { manager, salesEmployee1, salesEmployee2, employee };

		int n = employees.length;
		
		EmployeeBasicSalaryAscendingComparator comparator = new EmployeeBasicSalaryAscendingComparator();

		for (int i = 1; i < n; ++i) {
			Employee key = employees[i];
			int j = i - 1;

			int r = comparator.compare(employees[j], key);

			while (j >= 0 && r > 0) {
				employees[j + 1] = employees[j];
				j = j - 1;
				if (j >= 0)
					r = comparator.compare(employees[j], key);
			}
			employees[j + 1] = key;
		}
		System.out.println("Insertion sort - Basic Ascending - Employees");
		System.out.println(Arrays.toString(employees));

	}

}
