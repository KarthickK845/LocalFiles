package com.training.ui;

import java.util.Arrays;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main14 {

	public static void main(String[] args) {
		
		Person person1 = new Person("Ram", 50);
		Person person2 = new Person("Sham", 14);

		Person[] persons = { person1, person2, new Person("Karthi", 30), new Person("Hari", 18) };

		int n = persons.length;
		
		PersonNameComparator comparator = new PersonNameComparator();

		for (int i = 1; i < n; ++i) {
			Person key = persons[i];
			int j = i - 1;

			int r = comparator.compare(persons[j], key);

			while (j >= 0 && r > 0) {
				persons[j + 1] = persons[j];
				j = j - 1;
				if (j >= 0)
					r = comparator.compare(persons[j], key);
			}
			persons[j + 1] = key;
		}
		System.out.println("Insertion sort - Person name - persons");
		System.out.println(Arrays.toString(persons));

	}

}
