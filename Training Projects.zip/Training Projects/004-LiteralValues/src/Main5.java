
public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Boolean literal
		System.out.println(true);
		System.out.println(false);
	}

}
