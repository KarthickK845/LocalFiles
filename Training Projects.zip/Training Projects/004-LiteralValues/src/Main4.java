
public class Main4 {

	public static void main(String[] args) {
		System.out.println("Welcome \t to \n J\u0061va Training");
		System.out.println("");
	}

}
