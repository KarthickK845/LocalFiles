import java.util.Scanner;

public class Main1 {

	public static void main(String[] args) {
		
		int age;
		
		Scanner sc = new Scanner(System.in);
		age=sc.nextInt();
		
		System.out.println(age);
		
		System.out.println(25345);	//int literal (decimal)
		System.out.println(04412);	//int literal (octal)
		System.out.println(0xf);	//int literal (hexa decimal)
		System.out.println(0b101);   //int literal (binary decimal)
	}

}
