
public class Main2 {

	public static void main(String[] args) {
		System.out.println(10.00);    //double type literal
		System.out.println(10.00F);		//float type literal
		System.out.println(1.1E4);		//double type literal using scientific notation 1.1 into 10 power 4
		System.out.println(3.4E-2);     //double type literal using scientific notation 3.4 into 10 power -2
		System.out.println(3.4E2F);
	}

}
