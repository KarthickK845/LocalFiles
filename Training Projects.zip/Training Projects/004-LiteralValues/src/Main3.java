
public class Main3 {

	public static void main(String[] args) {
		//character literal
		System.out.println('A');
		System.out.println('a');	//     \u0061
		System.out.println('7');
		System.out.println('?');
		System.out.println('\t');
		
		//unicode value notations (hexadecimal value)
		
		//1 into 16 power 0
		//4 into 15 power 1
		System.out.println('\u0041');
	}

}
