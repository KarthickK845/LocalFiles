package com.training.model;

public class Square implements Comparable{
	private int size;

	public Square(int size) {
		super();
		this.size = size;
	}

	@Override
	public int compareTo(Object o) {
		Square s1 = (Square) o;
		if(this.size<s1.size)
			return -1;
		if(this.size>s1.size)
			return 1;
		return 0;
	}
	
	
}
