package com.training.ui;

import com.training.model.Person;

public class Main3 {

	public static void main(String[] args) {
		Person person1 = new Person("Karthick", 21);
		Person person2 = new Person("Krishna", 20);
		
		int res = person1.compareTo(person2);
		System.out.println("Person");
		System.out.println(res);
		
		if(res<0)
			System.out.println("Age of person1 is lesser than person2");
		if(res==0)
			System.out.println("Age of person1 is equal to person2");
		if(res>0)
			System.out.println("Age of person1 is greater than person2");
	}

}
