package com.training.ui;

import com.training.model.Circle;

public class Main1 {

	public static void main(String[] args) {
		Circle c1 = new Circle(20);
		Circle c2 = new Circle(10);
		
		//compare c1 with c2 if less, equal or greater
		int r = c1.compareTo(c2);  //c1 is invoking compareTo method
		System.out.println("Circle");
		System.out.println(r);
		
		if(r<0)
			System.out.println("Circle c1 is smaller than circle c2");
		if(r==0)
			System.out.println("Circle c1 is same size as circle c2");
		if(r>0)
			System.out.println("Circle c1 is bigger than circle c2");
	}

}
