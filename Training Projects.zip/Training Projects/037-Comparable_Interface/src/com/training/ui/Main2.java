package com.training.ui;

import com.training.model.Square;

public class Main2 {

	public static void main(String[] args) {
		Square sq1 = new Square(44);
		Square sq2 = new Square(24);
		
		int r = sq1.compareTo(sq2);
		System.out.println("Square");
		System.out.println(r);
		
		if(r<0)
			System.out.println("Square sq1 is smaller than Square sq2");
		if(r==0)
			System.out.println("Square sq1 is same size as Square sq2");
		if(r>0)
			System.out.println("Square sq1 is bigger than Square sq2");
	}

}
