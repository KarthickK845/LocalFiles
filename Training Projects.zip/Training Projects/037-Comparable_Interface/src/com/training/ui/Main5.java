package com.training.ui;

import com.training.model.Account;

public class Main5 {

	public static void main(String[] args) {
		Account account1 = new Account("Karishma", 50000.00);
		Account account2 = new Account("Abdul", 70000.00);
		
		int r=account1.compareTo(account2);
		System.out.println(r);
		
		if(r<0)
			System.out.println("account1 balance is less than account2 balance");
		if(r==0)
			System.out.println("account1 balance is equal to account2 balance");
		if(r>0)
			System.out.println("account1 balance is greater than account2 balance");

	}

}
