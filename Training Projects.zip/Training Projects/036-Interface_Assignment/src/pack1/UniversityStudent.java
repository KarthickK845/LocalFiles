package pack1;

public class UniversityStudent implements Student{

	@Override
	public void enroll() {
		System.out.println("University Student Enrolled");
	}

	@Override
	public void takeExam() {
		System.out.println("University Student Taken Exam");
	}

	@Override
	public void leave() {
		System.out.println("University Student Taken Leave");
	}
	
}
