package pack1;

public abstract class I {
	
	//only concrete methods here
	public void test1() {
		System.out.println("test1 in I");
	}
	
	public void test2() {
		System.out.println("test2 in I");
	}
}
