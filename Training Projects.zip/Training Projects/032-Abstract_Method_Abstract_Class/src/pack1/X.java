package pack1;

public abstract class X {
	public abstract void test1();
	public abstract void test2();
	public abstract void test3();
	public abstract void test4();
}
