package pack1;

public class J extends I{
    
}
