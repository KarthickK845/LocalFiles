package pack1;

public class Z extends Y{

//	@Override
//	public void test4() {
//		System.out.println("Z test4");
//	}

}
