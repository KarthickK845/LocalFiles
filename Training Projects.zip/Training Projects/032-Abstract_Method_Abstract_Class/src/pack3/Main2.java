package pack3;

import pack1.X;
import pack1.Z;

public class Main2 {

	public static void main(String[] args) {
		
		X obj = new Z();
		obj.test4();
	}

}
