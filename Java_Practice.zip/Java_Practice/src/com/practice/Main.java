package com.practice;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		
		String str = "$123, I Am a }9) Java Devloper@3";
		System.out.println(sumOfDigits(str));
		
		System.out.println(singleCharacters(str));
	}
	
	public static int sumOfDigits(String str){
		int sum = str.chars()
		.filter(Character::isDigit)
		.mapToObj(Character::getNumericValue)
		.reduce(0, (a,b)->a+b);
		
		return sum;
	}
	
	public static List<Character> singleCharacters(String str){
		Map<Character,Long> charMap = str.chars()
		.filter(Character::isLetter)
		.mapToObj(c->((char)c))
		.collect(Collectors.groupingBy(c->c,Collectors.counting()));
		
		 List<Character> singleCharacters = charMap.entrySet().stream()
		.filter(entry -> entry.getValue()==1)
		.map(entry -> entry.getKey())
		.collect(Collectors.toList());
		 
		 return singleCharacters;
		 
		
	}

}
