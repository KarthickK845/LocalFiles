package com.practice;

import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main2 {

	public static void main(String[] args) {
		int[] input = { 1111, 9999, 1234, 5678, 9091 };
		
		for(int in : input) {
			System.out.println(sum(in));
		}

	}
	
	public static int sum(int number) {
		int sum = String.valueOf(number)
		.chars().mapToObj(Character::getNumericValue)
		.reduce(0,(n1,n2)->n1+n2);
		
		return sum;
	}

	public static int totalSum(int[] input) {
		for(int number : input) {
			String.valueOf(number)
			.chars().flatMap(i->Stream.of(i))
			.sum();
			
		}
		
	}
}
